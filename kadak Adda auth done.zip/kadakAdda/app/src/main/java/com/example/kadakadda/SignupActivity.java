package com.example.kadakadda;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class SignupActivity extends AppCompatActivity {


    EditText usrnm,usrmail,usrpwrd,usrmob;
    Button go;

    FirebaseAuth fauth;
    FirebaseFirestore firebaseDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);
        usrnm=findViewById(R.id.user_name);
        usrmail=findViewById(R.id.user_id);
        usrpwrd=findViewById(R.id.confirm_password);
        usrmob=findViewById(R.id.mobile_number);

        fauth = FirebaseAuth.getInstance();
        firebaseDatabase = FirebaseFirestore.getInstance();

        go=findViewById(R.id.lets_go);


        go.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                final String n = usrnm.getText().toString().trim();
                final String m = usrmail.getText().toString().trim();
                final String p = usrpwrd.getText().toString().trim();
                final String mo = usrmob.getText().toString().trim();


                if (TextUtils.isEmpty(n)) {
                    usrnm.setError("Enter name");
                } else if (TextUtils.isEmpty(m)) {
                    usrmail.setError("Enter Email");
                } else if (TextUtils.isEmpty(p) && p.length() > 6) {
                    usrpwrd.setError("Enter Password");
                } else if (TextUtils.isEmpty(mo)) {
                    usrmob.setError("Enter mob");
                } else {

                    fauth.createUserWithEmailAndPassword(m, p).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (task.isSuccessful()) {
                                Intent intent=new Intent(getApplicationContext(),MainActivity.class);
                                startActivity(intent);
                                }
                            else {
                                Toast.makeText(SignupActivity.this, "failed", Toast.LENGTH_SHORT).show();
                            }

                        }
                    });
                    }
                    }
                    });

    }

}